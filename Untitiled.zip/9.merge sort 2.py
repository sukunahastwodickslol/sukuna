def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr) // 2
        left = arr[:mid]
        right = arr[mid:]

        merge_sort(left)
        merge_sort(right)

        i = j = k = 0

        while i < len(left) and j < len(right):
            if left[i]['time'] < right[j]['time']:
                arr[k] = left[i]
                i += 1
            else:
                arr[k] = right[j]
                j += 1
            k += 1

        while i < len(left):
            arr[k] = left[i]
            i += 1
            k += 1

        while j < len(right):
            arr[k] = right[j]
            j += 1
            k += 1


orders = []

n = int(input("Enter number of orders: "))

for i in range(n):
    id = input("Enter order ID: ")
    time = int(input("Enter delivery time: "))
    orders.append({'id': id, 'time': time})

merge_sort(orders)

print("Sorted Orders:")
for order in orders:
    print(order['id'], order['time'])