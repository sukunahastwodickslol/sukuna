
class Node:
    def __init__(self, key):
        self.left = None
        self.right = None
        self.val = key    

def insert(root, key):
    if root is None:
        return Node(key)

    if key < root.val:
        root.left = insert(root.left, key)

    elif key > root.val:
        root.right = insert(root.right, key)
   
    return root

def delete(root, key):
    if root is None:
        return root

    if key < root.val:
        root.left = delete(root.left, key)

    elif key> root.val:
        root.right = delete(root.right, key)

    else:
        if root.left is None:
            return root.right

        elif root.right is None:
            return root.left

        temp = root.right
        while temp.left:
            temp = temp.left

        root.val = temp.val
        root.right = delete(root.right, temp.val)

    return root

def inorder(root):
    if root:
        inorder(root.left)
        print(root.val, end=" ")
        inorder(root.right)

r = None

while True:
    print("\n1. Insert\n2. Delete\n3. Inorder traversal\n4. Exit")
    choice = int(input("\nenter your choice:"))

    if choice == 1:
        key = int(input("enter the value to insert:"))
        r = insert(r, key)

    elif choice == 2:
        key = int(input("enter the value to delete:"))
        r = delete(r, key)

    elif choice == 3:
        print("inorder traversal of BST:")
        inorder(r)

    elif choice == 4:
        break

    else:
        print("invalid choice")
