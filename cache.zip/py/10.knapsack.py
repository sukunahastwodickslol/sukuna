n = int(input("Enter number of parcels: "))

parcels = []

for i in range(n):
    id = input("Enter parcel ID: ")
    w = float(input("Enter weight: "))
    p = float(input("Enter profit: "))
    parcels.append([id, w, p])

capacity = float(input("Enter truck capacity: "))

parcels.sort(key=lambda x: x[2]/x[1], reverse=True)

total = 0

for parcel in parcels:
    if capacity == 0:
        break

    if parcel[1] <= capacity:
        total += parcel[2]
        capacity -= parcel[1]
    else:
        total += parcel[2] * capacity / parcel[1]
        capacity = 0

print("Maximum Profit =", round(total, 2)) 