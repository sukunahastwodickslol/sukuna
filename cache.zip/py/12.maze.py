
from collections import deque

maze = [
    ['S', '0', '#', '0', '0'],
    ['0', '0', '#', '0', '#'],
    ['#', '0', '0', '0', '0'],
    ['0', '#', '#', '#', '0'],
    ['0', '0', '0', '0', 'G']
]
rows = len(maze)
cols = len(maze[0])

start = (0, 0)
goal = (4, 4)

queue = deque([start])
visited = [start]
parent = {}

directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]

while queue:
    x, y = queue.popleft()

    if (x, y) == goal:
        break

    for dx, dy in directions:
        nx = x + dx
        ny = y + dy

        if (0 <= nx < rows and 0 <= ny < cols
                and maze[nx][ny] != '#'
                and (nx, ny) not in visited):

            queue.append((nx, ny))
            visited.append((nx, ny))
            parent[(nx, ny)] = (x, y)

if goal in visited:
    path = []
    current = goal

    while current != start:
        path.append(current)
        current = parent[current]

    path.append(start)
    path.reverse()

    for x, y in path:
        if maze[x][y] != 'S' and maze[x][y] != 'G':
            maze[x][y] = '*'

    print("Path Found:")

    for row in maze:
        print(" ".join(row))

    print("Path:", path)
    print("Path length:", len(path) - 1)

else:
    print("No path found!")
