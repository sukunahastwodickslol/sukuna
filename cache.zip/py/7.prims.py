
n = int(input("Enter number of departments: "))

print("Enter adjacency matrix:")
graph = []

for i in range(n):
    row = list(map(int, input().split()))
    graph.append(row)

visited = [False] * n
visited[0] = True

total = 0
count = 0

print("\nMinimum Spanning Tree:")

while count < n - 1:
    minimum = 999
    u = -1
    v = -1

    for i in range(n):
        if visited[i]:
            for j in range(n):
                if not visited[j] and graph[i][j] != 0:
                    if graph[i][j] < minimum:
                        minimum = graph[i][j]
                        u = i
                        v = j

    if u == -1:
        print("Graph is disconnected")
        break

    print(u, "-", v, ":", minimum)

    visited[v] = True
    total += minimum
    count += 1

print("Minimum total distance =", total)
