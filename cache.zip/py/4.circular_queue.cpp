
#include <stdio.h>
#define SIZE 5

int q[SIZE], front = -1, rear = -1;

void enqueue() {
    int x;

    if ((rear + 1) % SIZE == front)
        printf("Queue Full\n");
    else {
        printf("Enter value: ");
        scanf("%d", &x);

        if (front == -1)
            front = 0;

        rear = (rear + 1) % SIZE;
        q[rear] = x;

        printf("Inserted: %d\n", x);
    }
}

void dequeue() {
    if (front == -1)
        printf("Queue Empty\n");
    else {
        printf("Deleted: %d\n", q[front]);

        if (front == rear)
            front = rear = -1;
        else
            front = (front + 1) % SIZE;
    }
}

void display() {
    int i;

    if (front == -1)
        printf("Queue Empty\n");
    else {
        printf("Queue: ");
        i = front;

        while (1) {
            printf("%d ", q[i]);
            if (i == rear) break;
            i = (i + 1) % SIZE;
        }
        printf("\n");
    }
}

int main() {
    int ch;

    while (1) {
        printf("\n1.Enqueue  2.Dequeue  3.Display  4.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &ch);

        switch (ch) {
            case 1: enqueue(); break;
            case 2: dequeue(); break;
            case 3: display(); break;
            case 4: return 0;
            default: printf("Invalid Choice\n");
        }
    }
}
