
def find(parent, i):
    while parent[i] != i:
        i = parent[i]
    return i


def union(parent, i, j):
    a = find(parent, i)
    b = find(parent, j)
    parent[a] = b


n = int(input("Enter number of departments: "))

print("Enter adjacency matrix:")
graph = []

for i in range(n):
    row = list(map(int, input().split()))
    graph.append(row)

edges = []

# Store all edges
for i in range(n):
    for j in range(i + 1, n):
        if graph[i][j] != 0:
            edges.append((graph[i][j], i, j))

# Sort edges by weight
edges.sort()

parent = [i for i in range(n)]

total = 0
count = 0

print("\nMinimum Spanning Tree:")

for weight, u, v in edges:
    a = find(parent, u)
    b = find(parent, v)

    if a != b:
        print(u, "-", v, ":", weight)
        total += weight
        union(parent, u, v)
        count += 1

        if count == n - 1:
            break

print("Minimum total distance =", total)
