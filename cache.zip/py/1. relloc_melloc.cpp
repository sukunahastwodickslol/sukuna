
#include <stdio.h>
#include <stdlib.h>

struct Student {
    int id;
    char name[50];
    float cgpa;
};

int main() {
    struct Student *s;
    int n, i;

    printf("Enter number of students: ");
    scanf("%d", &n);

    s = (struct Student*)malloc(n * sizeof(struct Student));

    for(i = 0; i < n; i++) {
        printf("\nEnter ID: ");
        scanf("%d", &s[i].id);

        printf("Enter Name: ");
        scanf("%s", s[i].name);

        printf("Enter CGPA: ");
        scanf("%f", &s[i].cgpa);
    }

    int new_n;
    printf("\nEnter number of additional students: ");
    scanf("%d", &new_n);

    s = (struct Student*)realloc(s, (n + new_n) * sizeof(struct Student));

    for(i = n; i < n + new_n; i++) {
        printf("\nEnter ID: ");
        scanf("%d", &s[i].id);

        printf("Enter Name: ");
        scanf("%s", s[i].name);

        printf("Enter CGPA: ");
        scanf("%f", &s[i].cgpa);
    }

    printf("\nStudent Records:\n");

    for(i = 0; i < n + new_n; i++) {
        printf("\nID: %d", s[i].id);
        printf("\nName: %s", s[i].name);
        printf("\nCGPA: %.2f\n", s[i].cgpa);
    }

    free(s);

    return 0;
}






